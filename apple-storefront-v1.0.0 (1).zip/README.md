# apple-storefront

Version **1.0.0** — customer-facing storefront built with Next.js, TypeScript, Tailwind CSS, and Vercel.

## Included

- Existing storefront and product sections
- NVIDIA-focused section and navigation
- Responsive Next.js storefront UI
- Tailwind CSS styling
- Vercel-ready deployment configuration

## Run locally

```bash
npm install
npm run dev
```

Then open the local development URL shown by Next.js.

## Production build

```bash
npm run release:check
npm run build
npm run start
```

## Deploy

Import this repository into Vercel or connect it to a Git provider.

Before production deployment:

1. Confirm the project is using version `1.0.0`.
2. Configure required environment variables in the deployment platform.
3. Run `npm run release:check`.
4. Run `npm run build`.
5. Deploy the resulting Next.js application.

## NVIDIA links

The storefront's NVIDIA section links to NVIDIA's official website and NVIDIA's LinkedIn company page.

## Scope

This project is an independent storefront implementation. No Apple-owned infrastructure, trademarks, domains, or accounts are modified by this project.
